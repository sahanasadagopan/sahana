//main() to execute project_1_report()


#include<stdio.h>
#include<stdint.h>
#include "project_1.h"
int main()
{
   project_1_report(); //call project_1_report() in project_1.c file
}
